var ground;
var play=1
var end=0
var gameState=play;
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
  
createCanvas(600,200);
  
  monkey=createSprite(50,160,20,50);
  monkey.addAnimation("running", monkey_running);
  monkey.scale=0.1;
  
  ground = createSprite(200,200,600,20)
  ground.x = ground.width /2;
  
  obstaclesGroup = createGroup();
  
  
  
}


function draw() {
  
  ground.velocityX=-2
  background("white")
  console.log(monkey);
  
   if(gameState === PLAY){

    gameOver.visible = false;
    restart.visible = false;
    
    
    if (ground.x < 0){
      ground.x = ground.width/2;
    }
    
    //jump when the space key is pressed
    if(keyDown("space")&& trex.y >= 100) {
        trex.velocityY = -12;
        jumpSound.play();
    }
    
    //add gravity
    trex.velocityY = trex.velocityY + 0.8
     
     
     
     //spawn obstacles on the ground
    spawnObstacles();
      
    }
   else if (gameState === END) {
      gameOver.visible = true;
      restart.visible = true;
     
     //change the trex animation
      trex.changeAnimation("collided", trex_collided);
    
      
  if(mousePressedOver(restart)) {
      reset();
    
    }
     
     
      ground.velocityX = 0;
      trex.velocityY = 0
      
     
      //set lifetime of the game objects so that they are never destroyed
    obstaclesGroup.setLifetimeEach(-1);
    cloudsGroup.setLifetimeEach(-1);
     
     obstaclesGroup.setVelocityXEach(0);
     cloudsGroup.setVelocityXEach(0);    
   }
  
 
  //stop trex from falling down
  trex.collide(invisibleGround);
 


  
  
  
  
  
  
  
  
  
  
  
  
  
  
  }
  
  
  
  
  
  
  
  
  
  if (ground.x < 2){

    ground.x = ground.width / 2; 
  }
  //jump when space key is pressed
  if (keyDown("space")) {
    monkey.velocityY=-10;
  }

monkey.velocityY = monkey.velocityY +0.5

  //stop trex from falling down
  monkey.collide(ground);
  spawnObstacles();
  drawSprites();

}

}




function spawnObstacles(){
 if (frameCount % 60 === 0){
   var obstacle = createSprite(600,165,10,40);
   
    //generate random obstacles
    var rand = Math.round(random(1,6));
    switch(rand) {
      case 1: obstacle.addImage(obstacleImage)
              break;
      case 2: obstacle.addImage(obstacleImage)
              break;
      case 3: obstacle.addImage(obstacleImage)
              break;
      case 4: obstacle.addImage(obstacleImage)
              break;
      case 5: obstacle.addImage(obstacleImage)
              break;
      case 6: obstacle.addImage(obstacleImage)
              break;
      default: break;
    }
   
    //assign scale and lifetime to the obstacle           
    obstacle.scale = 1;
    obstacle.lifetime = 300;
   
   //add each obstacle to the group
    obstaclesGroup.add(obstacle);
 }





